package com.ipn.mx.evento.controller;


import com.ipn.mx.evento.domain.Evento;
import com.ipn.mx.evento.service.EventoService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.dao.DataAccessException;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.HashMap;
import java.util.List;
import java.util.Map;

@RestController
@RequestMapping("/api/v1/ApiEventos")
public class EventoController {
    @Autowired
    private EventoService eventoService;

    @GetMapping("/eventos")
    @ResponseStatus(HttpStatus.OK)
    public List<Evento> readAll(){
        return eventoService.findAll();
    }

    @GetMapping("/eventos/{id}")
    public ResponseEntity<?> read (@PathVariable Long id){
        Evento evento = null;
        Map<String, Object> respuesta = new HashMap<>();
        try {
            evento = eventoService.findById(id);
        }catch (DataAccessException e) {
            respuesta.put("mensaje", "Error al realizar la consulta");
            respuesta.put("error", e.getMessage()
                    .concat(" = ")
                    .concat(e.getMostSpecificCause().getMessage())
            );
            return new ResponseEntity<Map<String, Object>>(respuesta, HttpStatus.INTERNAL_SERVER_ERROR);
        }
        if (evento == null){
            respuesta.put("mensaje", "El evento".concat(id.toString()).concat("no existe en la base de datos"));
            return new ResponseEntity<Map<String,Object>>(respuesta, HttpStatus.NOT_FOUND);
        }
        return new ResponseEntity<Evento>(evento, HttpStatus.OK);
    }

}
