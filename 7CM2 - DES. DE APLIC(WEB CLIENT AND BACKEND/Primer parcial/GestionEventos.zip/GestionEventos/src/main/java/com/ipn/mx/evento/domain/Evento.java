package com.ipn.mx.evento.domain;

import jakarta.persistence.*;
import jakarta.validation.constraints.NotBlank;
import jakarta.validation.constraints.NotNull;
import jakarta.validation.constraints.Size;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;
import org.hibernate.annotations.Temporal;

import java.io.Serializable;
import java.time.LocalDate;

@AllArgsConstructor
@NoArgsConstructor
@Data
@Entity(name = "Evento")

public class Evento implements Serializable {
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    @Column(name = "Evento", nullable = true)
    private Long idEvento;

    @NotBlank(message = "El nombre del evento no debe estar vacío")
    @Size(min = 4, max = 200,message = "El nombre del evento debe tener entre 4-200 caracteres")
    @Column(name = "nombreEvento",length = 200, nullable = true,unique = true)
    private String nombreEvento;

    @NotBlank(message = "La descripcion del evento no debe estar vacía")
    @Size(min = 4, max = 500,message = "El nombre del evento debe tener entre 4-500 caracteres")
    @Column(name = "descripcionEvento", length = 500, nullable = true)
    private String descripcionEvento;


    //@Temporal(TemporalType.DATE)
    @NotNull(message = "La fecha es obligatoria")
    @Column(name = "fechaCreacion", nullable = false)
    private LocalDate fechaCreacion;

}
